// 1.4 箭頭函式

const f1 = a => a*a;
// console.log(f1(9));
// console.log(__dirname);
module.exports = f1; //讓require01.js可以引用