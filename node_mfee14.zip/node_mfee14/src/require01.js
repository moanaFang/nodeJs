const f2 = require(__dirname + '\\func01.js'); //檔案路徑
console.log(f2(8));

