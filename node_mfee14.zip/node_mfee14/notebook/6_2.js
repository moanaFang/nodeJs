/*
server side render

前端框架 client side render

前端javascript 生出來

在這裡定義自己的midware

會不會打架

先後順序的問題

往下傳遞

widware 做登入

req res

widware 過濾器

d套件預設值，可能會改變，強迫要設定

session 存放資料庫 儲存影響

內容沒有變更，強制回存


*/